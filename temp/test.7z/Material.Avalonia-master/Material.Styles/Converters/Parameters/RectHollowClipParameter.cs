﻿using Avalonia;

namespace Material.Styles.Converters.Parameters
{
    public class RectHollowClipParameter
    {
        public Thickness Margin { get; set; }
        public Point Offset { get; set; }
    }
}