﻿namespace Material.Styles.Themes.Base
{
    public enum BaseThemeMode
    {
        Inherit,
        Light,
        Dark
    }
}