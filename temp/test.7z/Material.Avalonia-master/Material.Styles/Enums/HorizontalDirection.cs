﻿namespace Material.Styles.Enums
{
    public enum HorizontalDirection
    {
        Left,
        Right
    }
}