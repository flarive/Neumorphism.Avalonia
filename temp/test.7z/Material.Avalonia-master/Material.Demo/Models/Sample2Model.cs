﻿namespace Material.Demo.Models
{
    public class Sample2Model
    {
        public Sample2Model(int number)
        {
            Number = number;
        }

        public int Number { get; set; }
    }
}