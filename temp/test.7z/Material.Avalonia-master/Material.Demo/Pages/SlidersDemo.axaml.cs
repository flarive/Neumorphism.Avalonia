﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class SlidersDemo : UserControl {
        public SlidersDemo() {
            this.InitializeComponent();
        }
    }
}
