﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class NotReadyDemo : UserControl {
        public NotReadyDemo() {
            this.InitializeComponent();
        }
    }
}
