﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class TabsDemo : UserControl {
        public TabsDemo() {
            this.InitializeComponent();
        }
    }
}
