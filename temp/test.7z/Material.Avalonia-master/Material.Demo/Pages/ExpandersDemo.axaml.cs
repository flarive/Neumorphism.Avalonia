﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ExpandersDemo : UserControl {
        public ExpandersDemo() {
            this.InitializeComponent();
        }
    }
}
