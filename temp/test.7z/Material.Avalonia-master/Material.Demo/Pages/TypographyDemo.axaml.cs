﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class TypographyDemo : UserControl {
        public TypographyDemo() {
            this.InitializeComponent();
        }
    }
}
