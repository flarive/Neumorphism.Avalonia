﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class TreeViewsDemo : UserControl {
        public TreeViewsDemo() {
            this.InitializeComponent();
        }
    }
}
