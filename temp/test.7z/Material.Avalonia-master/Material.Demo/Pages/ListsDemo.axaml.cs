﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ListsDemo : UserControl {
        public ListsDemo() {
            this.InitializeComponent();
        }
    }
}
