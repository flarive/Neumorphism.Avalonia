﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ButtonsDemo : UserControl {
        public ButtonsDemo() {
            this.InitializeComponent();
        }
    }
}
