﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ColorZonesDemo : UserControl {
        public ColorZonesDemo() {
            this.InitializeComponent();
        }
    }
}
