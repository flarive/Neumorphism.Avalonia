﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ComboBoxesDemo : UserControl {
        public ComboBoxesDemo() {
            this.InitializeComponent();
        }
    }
}
