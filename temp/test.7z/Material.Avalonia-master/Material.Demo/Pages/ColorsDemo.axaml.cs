using Avalonia.Controls;

namespace Material.Demo.Pages;

public partial class ColorsDemo : UserControl
{
    public ColorsDemo()
    {
        InitializeComponent();
    }
}