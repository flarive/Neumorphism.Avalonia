﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class CardsDemo : UserControl {
        public CardsDemo() {
            this.InitializeComponent();
        }
    }
}
