using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class DateTimePickerDemo : UserControl {
        public DateTimePickerDemo() {
            InitializeComponent();
        }
    }
}
