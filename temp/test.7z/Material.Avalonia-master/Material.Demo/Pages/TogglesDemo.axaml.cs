﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class TogglesDemo : UserControl {
        public TogglesDemo() {
            this.InitializeComponent();
        }
    }
}
