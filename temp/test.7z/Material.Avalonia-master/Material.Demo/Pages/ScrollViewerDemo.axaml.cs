﻿using Avalonia.Controls;

namespace Material.Demo.Pages {
    public partial class ScrollViewerDemo : UserControl {
        public ScrollViewerDemo() {
            this.InitializeComponent();
        }
    }
}
