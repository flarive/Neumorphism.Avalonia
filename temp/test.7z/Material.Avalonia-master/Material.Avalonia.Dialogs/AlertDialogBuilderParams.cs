﻿using Material.Dialog.Bases;

namespace Material.Dialog
{
    public class AlertDialogBuilderParams : DialogWindowBuilderParamsBase
    {
    }
}