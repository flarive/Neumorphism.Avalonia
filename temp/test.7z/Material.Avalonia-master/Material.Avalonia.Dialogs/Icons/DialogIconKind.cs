﻿namespace Material.Dialog.Icons
{
    public enum DialogIconKind
    {
        Error,
        Success,
        Info,
        Warning,
        Help,
        Issues,
        Stop,
        Blocked
    }
}