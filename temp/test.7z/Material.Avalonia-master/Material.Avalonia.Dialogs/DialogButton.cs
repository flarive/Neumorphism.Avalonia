﻿namespace Material.Dialog
{
    public class DialogButton
    {
        public string Result = "None";
        public object Content = "Action";
        public bool IsPositive = false;
        public bool IsNegative = false;
    }
}