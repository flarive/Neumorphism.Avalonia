﻿namespace Material.Dialog.Interfaces
{
    public interface IHasNegativeResult
    {
        void SetNegativeResult(DialogResult result);
    }
}