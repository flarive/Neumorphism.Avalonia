﻿namespace Material.Dialog.Interfaces
{
    public interface IDialogResult
    {
        string GetResult { get; }
    }
}