﻿namespace Material.Dialog.ViewModels.Elements.Header.Icons
{
    public class IconViewModelBase : DialogViewModelBase
    {
    }
}