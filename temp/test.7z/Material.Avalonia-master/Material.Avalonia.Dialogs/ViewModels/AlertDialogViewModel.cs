﻿using Material.Dialog.Views;

namespace Material.Dialog.ViewModels
{
    public class AlertDialogViewModel : DialogWindowViewModel
    {
        public AlertDialogViewModel(AlertDialog dialog) : base(dialog)
        {
        }
    }
}