﻿namespace Material.Dialog
{
    public class TextFieldResult
    {
        public string Text { get; set; }
    }
}