﻿using Avalonia.Controls;

namespace Material.Dialog.Controls
{
    public class EmbeddedDialogControl : ContentControl
    {
    }
}