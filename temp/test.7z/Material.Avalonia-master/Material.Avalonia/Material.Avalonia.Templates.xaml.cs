namespace Material.Avalonia
{
    public class MaterialAvaloniaTemplates : global::Avalonia.Styling.Styles
    {
    }
}